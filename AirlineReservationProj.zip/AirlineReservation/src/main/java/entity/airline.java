package entity;

import java.util.Date;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class airline {
	@Id
	private int id;
	private String source;
	private String destination;
	private int price;
	private Date addDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getAddDate() {
		return addDate;
	}
	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}
	public airline(int id, String source, String destination, int price, Date addDate) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.price = price;
		this.addDate = addDate;
	}
	public airline() {
		super();
		// TODO Auto-generated constructor stub
	}

}
