package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.airline;
import helper.factoryProvider;

public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Delete() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			 int id = Integer.parseInt(request.getParameter("id"));
		        
		        // Retrieve the airline entity from the database
		        Session session = factoryProvider.getFactory().openSession();
		        Transaction transaction = session.beginTransaction();
		        airline airline = session.get(airline.class, id);
		        
		        // Delete the entity
		        session.delete(airline);
		        
		        // Commit the transaction and close the session
		        transaction.commit();
		        session.close();
		        
		        // Redirect back to the page displaying the remaining records
		        response.sendRedirect("show.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
