package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.airline;
import helper.factoryProvider;

/**
 * Servlet implementation class Add
 */
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			int id = Integer.parseInt(request.getParameter("id"));
		    String source = request.getParameter("source");
		    String destination = request.getParameter("destination");
		    int price = Integer.parseInt(request.getParameter("price"));
		    String dateString = request.getParameter("date");
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    Date addDate = dateFormat.parse(dateString);

		    airline airline = new airline();
		    airline.setId(id);
		    airline.setSource(source);
		    airline.setDestination(destination);
		    airline.setPrice(price);
		    airline.setAddDate(addDate);

		    Session s = factoryProvider.getFactory().openSession();
		    Transaction tx = s.beginTransaction();
		    s.save(airline);
		    tx.commit();
		    s.close();

		    response.setContentType("text/html");
		    PrintWriter out = response.getWriter();
		    out.println("<h1 style='text-align:center'>Added successfully</h1>");
		   

		} catch (Exception e) {
		    e.printStackTrace();
		}
	}

}
